from random import randint
Names = ["Rock","Paper","Scissors"]
a = int(input("Rock(0), Paper(1) or Scissors(2)?"))
if a == 0 or a == 1 or a == 2:
  print("You chose " + Names[a])
  b = randint(0, 2)
  print("I choose " + Names[b])
  if a == b:
    print("Draw!")
  elif a == b + 1 or a == 0 and b == 2:
    print("You win!")
  else:
    print("I win!")